<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="relative working-hours-gen"class="hide reports_fr">
   <div id="working-hours-gen" class="reports"></div>
</div>